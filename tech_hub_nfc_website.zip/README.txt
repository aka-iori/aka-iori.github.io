TECH HUB FES — NFC WEBSITE

Files:
- index.html: main website (must remain named index.html)
- images/tech-hub-services.jpg: your services/contact poster
- images/tech-hub-logo-animation.jpg: your Tech Hub logo animation storyboard

Publish for free with GitHub Pages:
1. Create a public repository named USERNAME.github.io (replace USERNAME with your exact GitHub username).
2. Upload index.html and the entire images folder, preserving the folder structure.
3. Go to Settings > Pages.
4. Select Deploy from a branch, branch main, folder /(root), then Save.
5. After publishing, test https://USERNAME.github.io on a phone.
6. Write that HTTPS URL to your NFC card with an NFC-writing app.

The website uses contact details printed on the images supplied by you:
+212 646 408 023, +212 771 745 965, Instagram tech_hub_fes, Fes Route Sefrou.
